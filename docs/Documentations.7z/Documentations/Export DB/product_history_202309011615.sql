INSERT INTO public.product_history (id,product_id,email_user,quantity,rating,created_at,updated_at) VALUES
	 ('cb68a57a-48a6-11ee-b84f-00ffb41493a0','67ae7713-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',99,NULL,'2023-09-01 16:06:10.946803','2023-09-01 16:06:10.946803'),
	 ('ce2ae7b5-48a6-11ee-b84f-00ffb41493a0','67ae7713-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',NULL,3.5,'2023-09-01 16:06:15.57534','2023-09-01 16:06:15.57534'),
	 ('d814f384-48a6-11ee-b84f-00ffb41493a0','6cfa7eee-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',99,NULL,'2023-09-01 16:06:32.208679','2023-09-01 16:06:32.208679'),
	 ('d88a1407-48a6-11ee-b84f-00ffb41493a0','6cfa7eee-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',99,NULL,'2023-09-01 16:06:32.976282','2023-09-01 16:06:32.976282'),
	 ('dacc2dbd-48a6-11ee-b84f-00ffb41493a0','6cfa7eee-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',NULL,3.5,'2023-09-01 16:06:36.764921','2023-09-01 16:06:36.764921'),
	 ('f348ee0e-48a6-11ee-b84f-00ffb41493a0','6eab322b-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',99,NULL,'2023-09-01 16:07:17.847809','2023-09-01 16:07:17.847809'),
	 ('f5bbb5d8-48a6-11ee-b84f-00ffb41493a0','6eab322b-489f-11ee-8401-00ffb41493a0','akuntes1@gmail.com',NULL,1.0,'2023-09-01 16:07:21.955478','2023-09-01 16:07:21.955478');
